SET NAMES utf8mb4;

INSERT INTO `genre` (`id`, `name`) VALUES
(1,	'Rock'),
(2,	'Jazz'),
(3,	'Hip-Hop'),
(4,	'Rap'),
(5,	'Reggae'),
(6,	'Country'),
(7,	'Electro'),
(8,	'Classique'),
(9,	'Metal');
