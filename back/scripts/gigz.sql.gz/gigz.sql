-- Adminer 4.8.1 MySQL 8.0.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `account` (`id`, `email`, `password`, `creation_date`, `phone_number`, `email_validated`, `profile_type`) VALUES
(1,	'alexandre.sparton@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 08:42:08',	'0648754884',	0,	'artist'),
(2,	'fil.veith@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:28:52',	NULL,	0,	'host'),
(3,	'lucas.nouhaud@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:29:21',	NULL,	0,	'host')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `email` = VALUES(`email`), `password` = VALUES(`password`), `creation_date` = VALUES(`creation_date`), `phone_number` = VALUES(`phone_number`), `email_validated` = VALUES(`email_validated`), `profile_type` = VALUES(`profile_type`);

INSERT INTO `account_genre` (`id`, `account_id`, `genre_id`) VALUES
(4,	1,	2)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `account_id` = VALUES(`account_id`), `genre_id` = VALUES(`genre_id`);

INSERT INTO `artist` (`id`, `name`, `description`, `spotify_link`, `instagram_link`, `facebook_link`, `soundcloud_link`, `youtube_link`, `apple_music_link`, `website_link`, `deezer_link`, `account_id`, `music_link`, `city`, `latitude`, `longitude`) VALUES
(4,	'Sickbee',	'Alexandre',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	NULL,	NULL)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `description` = VALUES(`description`), `spotify_link` = VALUES(`spotify_link`), `instagram_link` = VALUES(`instagram_link`), `facebook_link` = VALUES(`facebook_link`), `soundcloud_link` = VALUES(`soundcloud_link`), `youtube_link` = VALUES(`youtube_link`), `apple_music_link` = VALUES(`apple_music_link`), `website_link` = VALUES(`website_link`), `deezer_link` = VALUES(`deezer_link`), `account_id` = VALUES(`account_id`), `music_link` = VALUES(`music_link`), `city` = VALUES(`city`), `latitude` = VALUES(`latitude`), `longitude` = VALUES(`longitude`);

INSERT INTO `capacity` (`id`, `max`, `color`, `bg_color`) VALUES
(1,	50,	'#24273a',	'#c6a0f6'),
(2,	100,	'#24273a',	'#ed8796'),
(3,	250,	'#24273a',	'#a6da95'),
(4,	500,	'#24273a',	'#8aadf4'),
(5,	25,	'#24273a',	'#b7bdf8')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `max` = VALUES(`max`), `color` = VALUES(`color`), `bg_color` = VALUES(`bg_color`);


INSERT INTO `genre` (`id`, `name`) VALUES
(1,	'Rock'),
(2,	'Jazz'),
(3,	'Hip-Hop'),
(4,	'Rap'),
(5,	'Reggae'),
(6,	'Country'),
(7,	'Electro'),
(8,	'Classique'),
(9,	'Metal')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`);

INSERT INTO `host` (`id`, `name`, `description`, `website_link`, `facebook_link`, `instagram_link`, `capacity_id`, `host_type_id`, `address`, `account_id`, `city`, `latitude`, `longitude`) VALUES
(1,	'Impressionne moi',	'\"Impressionne moi\" is a vibrant French bar that specializes in offering a unique and entertaining experience centered around fun and feet. Located in the heart of the city, this lively establishment is dedicated to creating a lively and memorable atmosphere for its patrons.\r\n\r\nUpon entering \"Impressionne moi,\" guests are greeted by an ambiance that exudes joy and excitement. The bar\'s eclectic decor, featuring vibrant colors and quirky foot-related elements, sets the stage for an unforgettable experience. From foot-shaped decorations to foot-themed artwork adorning the walls, every detail reflects the bar\'s playful theme.\r\n\r\nThe menu at \"Impressionne moi\" is as delightful as its ambiance. Patrons can indulge in a wide array of foot-themed drinks and cocktails creatively crafted by expert mixologists. Each concoction is carefully designed to tickle the taste buds while keeping the fun atmosphere alive. Alongside the imaginative drinks, the bar also offers a selection of delicious snacks and light bites to complement the beverages.',	NULL,	NULL,	NULL,	5,	1,	'45 rue des pieds',	2,	NULL,	NULL,	NULL),
(2,	'Le Lapin Fou',	'\"Le Lapin Fou\" is an enchanting French restaurant that offers a unique culinary experience centered around cocktails, the vibrant personality of Nadine Morano, and the warmth of the sun. Nestled in a charming location, this restaurant invites guests to indulge in a delightful fusion of flavors, ambiance, and cultural influences.\r\n\r\nThe heart and soul of \"Le Lapin Fou\" lie in its exceptional cocktail selection. Talented mixologists craft innovative and tantalizing concoctions that take guests on a sensory journey. Each sip is an explosion of flavors, perfectly balanced to please even the most discerning palates. From classic cocktails with a twist to daring and inventive creations, the menu offers a delightful range of libations that can be savored in a relaxed and welcoming atmosphere.\r\n\r\nAdding a touch of personality to the restaurant is the influence of Nadine Morano, a well-known figure in French politics. Her charismatic presence is subtly woven into the restaurant\'s theme, paying homage to her vibrant character and passion. Guests can expect a playful yet sophisticated ambiance that reflects Morano\'s vivacious spirit and zest for life.\r\n\r\nTo complete the experience, \"Le Lapin Fou\" basks in the warmth of the sun. The restaurant boasts a beautiful outdoor seating area, bathed in natural light, where patrons can enjoy their meals and drinks while embracing the gentle rays of the sun. This creates an atmosphere of tranquility and relaxation, inviting guests to unwind and savor their dining experience.\r\n\r\nIn summary, \"Le Lapin Fou\" is an extraordinary French restaurant that merges the art of mixology, the lively essence of Nadine Morano, and the soothing embrace of the sun. It offers a culinary haven where guests can immerse themselves in a world of exceptional cocktails, delightful flavors, and a vibrant atmosphere that celebrates the joie de vivre.\r\n\r\n\r\n\r\n\r\n',	NULL,	NULL,	NULL,	2,	3,	'5 ter avenue du Grand Terrier',	3,	NULL,	NULL,	NULL)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `description` = VALUES(`description`), `website_link` = VALUES(`website_link`), `facebook_link` = VALUES(`facebook_link`), `instagram_link` = VALUES(`instagram_link`), `capacity_id` = VALUES(`capacity_id`), `host_type_id` = VALUES(`host_type_id`), `address` = VALUES(`address`), `account_id` = VALUES(`account_id`), `city` = VALUES(`city`), `latitude` = VALUES(`latitude`), `longitude` = VALUES(`longitude`);

INSERT INTO `host_type` (`id`, `name`, `color`, `bg_color`) VALUES
(1,	'Bar',	'#24273a',	'#ee99a0'),
(2,	'Salle de concert',	'#24273a',	'#f5a97f'),
(3,	'Restaurant',	'#24273a',	'#8bd5ca')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `color` = VALUES(`color`), `bg_color` = VALUES(`bg_color`);


INSERT INTO `profile_pictures` (`id`, `account_id`, `media`) VALUES
(2,	1,	'image2.png')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `account_id` = VALUES(`account_id`), `media` = VALUES(`media`);


-- 2023-07-17 08:24:35
