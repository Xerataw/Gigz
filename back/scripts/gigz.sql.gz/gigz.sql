-- Adminer 4.8.1 MySQL 8.0.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `account` (`id`, `email`, `password`, `creation_date`, `phone_number`, `email_validated`, `profile_type`) VALUES
(1,	'alexandre.sparton@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 08:42:08',	NULL,	0,	'artist'),
(2,	'fil.veith@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:28:52',	NULL,	0,	'host'),
(3,	'lucas.nouhaud@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:29:21',	NULL,	0,	'host')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `email` = VALUES(`email`), `password` = VALUES(`password`), `creation_date` = VALUES(`creation_date`), `phone_number` = VALUES(`phone_number`), `email_validated` = VALUES(`email_validated`), `profile_type` = VALUES(`profile_type`);










-- 2023-07-04 14:20:18
