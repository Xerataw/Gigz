-- Adminer 4.8.1 MySQL 8.0.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `account` (`id`, `email`, `password`, `creation_date`, `phone_number`, `email_validated`, `profile_type`) VALUES
(1,	'alexandre.sparton@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 08:42:08',	NULL,	0,	'artist'),
(2,	'fil.veith@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:28:52',	NULL,	0,	'host'),
(3,	'lucas.nouhaud@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:29:21',	NULL,	0,	'host'),
(4,	'amaury.bourguet@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:31:25',	NULL,	0,	'host'),
(5,	'alexis.moins@epitech.eu',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 11:31:55',	NULL,	0,	'host'),
(6,	'bob@marley@gigz.com',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 12:25:18',	NULL,	0,	'host'),
(7,	'frank.sinatra@gigz.com',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 12:28:04',	NULL,	0,	'host'),
(8,	'metallica@gigz.com',	'$2b$10$d5npoWLKZNOp71DnN.78CuDaEkmI0zA8s95sfOH4AyJqG7bEqvYFa',	'2023-06-20 12:49:37',	NULL,	0,	'host'),
(9,	'root.root@gigz.com',	'$2b$10$SJZ1GgfXE4MKFhDTYJWza.8roHIK9nm7WqldtjQc5YX8LFJGfcG0m',	'2023-07-04 09:21:14',	'0783243627',	0,	'host')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `email` = VALUES(`email`), `password` = VALUES(`password`), `creation_date` = VALUES(`creation_date`), `phone_number` = VALUES(`phone_number`), `email_validated` = VALUES(`email_validated`), `profile_type` = VALUES(`profile_type`);

INSERT INTO `account_genre` (`id`, `account_id`, `genre_id`) VALUES
(2,	6,	5),
(1,	7,	2),
(3,	8,	9),
(4,	9,	1),
(5,	9,	2)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `account_id` = VALUES(`account_id`), `genre_id` = VALUES(`genre_id`);

INSERT INTO `artist` (`id`, `name`, `description`, `spotify_link`, `instagram_link`, `facebook_link`, `soundcloud_link`, `youtube_link`, `apple_music_link`, `website_link`, `deezer_link`, `account_id`, `music_link`, `city`, `longitude`, `latitude`) VALUES
(1,	'Bob Marley',	'Bob Marley, the Jamaican music legend, revolutionized reggae and stood as a beacon of social change. Born in 1945, his music fused infectious rhythms with heartfelt lyrics, resonating with people worldwide. Hits like \"One Love,\" \"No Woman, No Cry,\" and \"Redemption Song\" exemplify his timeless sound. Marley\'s unwavering commitment to justice and peace made him a symbol of hope. His performances at historic events amplified the voices of the oppressed, showcasing the power of music to inspire change. Marley\'s influence transcends his passing in 1981, as his music continues to spread messages of love, unity, and social justice. His image and music are synonymous with reggae, representing freedom and resilience. Bob Marley\'s legacy celebrates the transformative power of music, unifying people across generations and borders. His indomitable spirit lives on, inspiring others and cementing his status as a cultural icon and musical revolutionary.',	'https://open.spotify.com/artist/6BH2lormtpjy3X9DyrGHVj',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	6,	NULL,	NULL,	NULL,	NULL),
(2,	'Frank Sinatra',	'Frank Sinatra, the legendary American singer and actor, captivated audiences with his velvety-smooth voice and magnetic stage presence. Born in 1915, Sinatra\'s six-decade career earned him 11 Grammy Awards. His versatility spanned genres like jazz, pop, swing, and even rock and roll. From heartfelt ballads to energetic up-tempo numbers, his voice evoked deep emotions and connected profoundly with listeners. Sinatra\'s discography boasts timeless classics like \"My Way,\" \"New York, New York,\" and \"Fly Me to the Moon.\" Collaborations with renowned arrangers and orchestras elevated his artistry, leaving an indelible mark. He also made significant contributions to acting, winning an Academy Award for \"From Here to Eternity.\" Sinatra embodied the Rat Pack era, exuding charisma and elegance. His cultural impact extends beyond his music, making him one of the greatest and most influential artists of the 20th century. Sinatra\'s name remains synonymous with timeless elegance, captivating vocals, and an enduring legacy that inspires listeners globally.',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	7,	NULL,	NULL,	NULL,	NULL),
(3,	'Metallica',	'Metallica, the iconic American heavy metal band, revolutionized the music industry with their powerful sound and raw energy. Formed in 1981, their blistering guitar riffs, thunderous drums, and intense vocals have captivated millions of fans worldwide. Hits like \"Enter Sandman,\" \"Master of Puppets,\" and \"Nothing Else Matters\" showcase their musical prowess and emotional depth. Metallica\'s unwavering dedication to their fans and philanthropic efforts have solidified their status as cultural icons. Their resilience and commitment inspire aspiring musicians and their influence on the metal genre is immeasurable. With a career spanning over four decades, Metallica\'s relentless sound continues to resonate with new generations, ensuring their legacy as one of the greatest heavy metal bands of all time.',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	8,	NULL,	NULL,	NULL,	NULL),
(4,	'Sickbee',	'Sickbee, the talented French rapper hailing from the Reunion Island, is a force to be reckoned with in the hip-hop scene. Born and raised on the Indian Ocean island, Sickbee infuses his music with a unique blend of local flavors and hard-hitting lyricism.\r\n\r\nWith his distinct flow and commanding stage presence, Sickbee delivers thought-provoking rhymes that tackle a range of social issues, personal struggles, and his deep connection to his cultural roots. His lyrics paint vivid pictures of life on the Reunion Island, offering a glimpse into its diverse and vibrant society.\r\n\r\nSickbee\'s music is a testament to his ability to seamlessly blend catchy melodies with hard-hitting beats, creating a sound that captivates listeners and keeps them engaged from start to finish. His tracks carry a powerful energy that resonates with fans both on the island and beyond.',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	NULL,	NULL)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `description` = VALUES(`description`), `spotify_link` = VALUES(`spotify_link`), `instagram_link` = VALUES(`instagram_link`), `facebook_link` = VALUES(`facebook_link`), `soundcloud_link` = VALUES(`soundcloud_link`), `youtube_link` = VALUES(`youtube_link`), `apple_music_link` = VALUES(`apple_music_link`), `website_link` = VALUES(`website_link`), `deezer_link` = VALUES(`deezer_link`), `account_id` = VALUES(`account_id`), `music_link` = VALUES(`music_link`), `city` = VALUES(`city`), `longitude` = VALUES(`longitude`), `latitude` = VALUES(`latitude`);

INSERT INTO `capacity` (`id`, `max`, `color`, `bg_color`) VALUES
(1,	50,	'#24273a',	'#c6a0f6'),
(2,	100,	'#24273a',	'#ed8796'),
(3,	250,	'#24273a',	'#a6da95'),
(4,	500,	'#24273a',	'#8aadf4'),
(5,	25,	'#24273a',	'#b7bdf8')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `max` = VALUES(`max`), `color` = VALUES(`color`), `bg_color` = VALUES(`bg_color`);


INSERT INTO `genre` (`id`, `name`) VALUES
(1,	'Rock'),
(2,	'Jazz'),
(3,	'Hip-Hop'),
(4,	'Rap'),
(5,	'Reggae'),
(6,	'Country'),
(7,	'Electro'),
(8,	'Classique'),
(9,	'Metal')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`);

INSERT INTO `host` (`id`, `name`, `description`, `website_link`, `facebook_link`, `instagram_link`, `capacity_id`, `host_type_id`, `account_id`, `address`, `city`, `longitude`, `latitude`) VALUES
(1,	'Alexis',	'C\'est un restaurant, oui, oui.',	NULL,	NULL,	NULL,	5,	1,	2,	'45 rue des pieds',	NULL,	NULL,	NULL),
(2,	'Alexis',	'C\'est un restaurant, oui, oui.',	NULL,	NULL,	NULL,	2,	3,	3,	'5 ter avenue du Grand Terrier',	NULL,	NULL,	NULL),
(3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	9,	NULL,	NULL,	NULL,	NULL)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `description` = VALUES(`description`), `website_link` = VALUES(`website_link`), `facebook_link` = VALUES(`facebook_link`), `instagram_link` = VALUES(`instagram_link`), `capacity_id` = VALUES(`capacity_id`), `host_type_id` = VALUES(`host_type_id`), `account_id` = VALUES(`account_id`), `address` = VALUES(`address`), `city` = VALUES(`city`), `longitude` = VALUES(`longitude`), `latitude` = VALUES(`latitude`);

INSERT INTO `host_type` (`id`, `name`, `color`, `bg_color`) VALUES
(1,	'Bar',	'#24273a',	'#ee99a0'),
(2,	'Salle de concert',	'#24273a',	'#f5a97f'),
(3,	'Restaurant',	'#24273a',	'#8bd5ca')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `color` = VALUES(`color`), `bg_color` = VALUES(`bg_color`);




-- 2023-07-11 14:58:30
