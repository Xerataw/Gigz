SET NAMES utf8mb4;

INSERT INTO `account_genre` (`id`, `account_id`, `genre_id`) VALUES
(2,	6,	5),
(1,	7,	2),
(3,	8,	9);
