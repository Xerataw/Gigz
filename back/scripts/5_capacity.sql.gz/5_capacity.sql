SET NAMES utf8mb4;

INSERT INTO `capacity` (`id`, `max`, `color`, `bg_color`) VALUES
(1,	50,	'#24273a',	'#c6a0f6'),
(2,	100,	'#24273a',	'#ed8796'),
(3,	250,	'#24273a',	'#a6da95'),
(4,	500,	'#24273a',	'#8aadf4'),
(5,	25,	'#24273a',	'#b7bdf8');
