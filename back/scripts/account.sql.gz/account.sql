SET NAMES utf8mb4;

INSERT INTO `account` (`id`, `email`, `password`, `creation_date`, `phone_number`, `email_validated`) VALUES
(1,	'test@gmail.com',	'123',	'2023-06-20 08:42:08',	NULL,	0);
