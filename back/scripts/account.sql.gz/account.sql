SET NAMES utf8mb4;

INSERT INTO `account` (`id`, `email`, `password`, `creation_date`, `phone_number`, `email_validated`) VALUES
(1,	'alexandre.sparton@epitech.eu',	'root',	'2023-06-20 08:42:08',	NULL,	0),
(2,	'fil.veith@epitech.eu',	'root',	'2023-06-20 11:28:52',	NULL,	0),
(3,	'lucas.nouhaud@epitech.eu',	'root',	'2023-06-20 11:29:21',	NULL,	0),
(4,	'amaury.bourguet@epitech.eu',	'root',	'2023-06-20 11:31:25',	NULL,	0),
(5,	'alexis.moins@epitech.eu',	'root',	'2023-06-20 11:31:55',	NULL,	0);
