SET NAMES utf8mb4;

INSERT INTO `host_type` (`id`, `name`, `color`, `bg_color`) VALUES
(1,	'Bar',	'#24273a',	'#ee99a0'),
(2,	'Salle de concert',	'#24273a',	'#f5a97f'),
(3,	'Restaurant',	'#24273a',	'#8bd5ca');
